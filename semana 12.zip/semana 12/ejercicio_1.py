import psycopg2

con = psycopg2.connect(
            host="localhost",
            database="laboratorio12",
            user="postgres",
            password="pokopo"
)

cur = con.cursor()

print("Inciso a)")
precio = float(input('Escribe un precio: '))
cur.execute('SELECT "price" as price1 FROM "PC" GROUP BY "price" ORDER BY "price" asc')
rows = cur.fetchall()
resultado1 = 10000
for r in rows:
    precio_querry = float(r[0])
    resultado = precio_querry - precio
    if resultado1 > resultado:
        resultado1 = resultado
r = string(resultado1)
print(r)

    
cur.close()
con.close()
